package studentRegistration;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
		private WebDriver driver;  
		private WebElement element;
			@Before
			public void setUp()
			{		driver=new ChromeDriver();
				System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		
			}
			
			
			@Given("^student registration form$")
			public void student_registration_form() throws Throwable {
				driver.get("http://localhost:8082/StudentRegForm/");
			}

			@When("^students details are valid$")
			public void students_details_are_valid() throws Throwable {
				element=driver.findElement(By.name("firstName"));
				element.sendKeys("Yamini");
				element=driver.findElement(By.name("lastName"));
				element.sendKeys("Ambati");
				element=driver.findElement(By.name("address"));
				element.sendKeys("Jeedimetla");
				element=driver.findElement(By.name("city"));
				element.sendKeys("Hyderabad");
				element=driver.findElement(By.name("state"));
				element.sendKeys("Telengana");
				element=driver.findElement(By.name("gender"));
				element.sendKeys("Female");
				element=driver.findElement(By.name("course"));
				element.sendKeys("BE");
				element=driver.findElement(By.name("mobilenum"));
				element.sendKeys("9874567890");
				element.submit();
				driver.switchTo().alert().accept();
			}

			@Then("^navigate into paymentForm$")
			public void navigate_into_paymentForm() throws Throwable {
				System.out.println(driver.switchTo().alert().getText());
		        driver.switchTo().alert().accept();
				//String url=driver.getCurrentUrl();
				// assertTrue(url.equals("http://localhost:8082/StudentRegForm/next"));
			}


	@After
	public void teardown()
	{
		//driver.close();
	} 
}
