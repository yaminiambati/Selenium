package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class pagebean {
WebDriver driver;
	
	@FindBy(name="firstName",how=How.NAME)
	private WebElement firstname;
	
	@FindBy(name="lastName")
	private WebElement lastname;
	
	@FindBy(name="address")
	private WebElement Address;
	
	@FindBy(name="city")
	private WebElement City;
	
	@FindBy(name="state")
	private WebElement State;
	 
@FindBy(name="gender")
	private WebElement Gender;
	
	@FindBy(name="course")
	private WebElement Course;
	
	@FindBy(name="mobilenum")
	private WebElement mobileno;
	
	@FindBy(name="next")
	private WebElement Next;
	
	 
public pagebean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	public void setFirstName(String fname) {
		firstname.sendKeys(fname);
	}
	public void setLastName(String lname) {
		lastname.sendKeys(lname);
	}
	public void setADDress(String addr) {
		Address.sendKeys(addr);
	}
	public void setCIty(String c) {
		City.sendKeys(c);
	}
	public void setSTate(String state) {
		State.sendKeys(state);
	}
	public void setGEnder(String gender) {
		Gender.sendKeys(gender);
	}
	public void setCOurse(String course) {
		Course.sendKeys(course);
	}
	public void setMobileNo(String Mobileno) {
		mobileno.sendKeys(Mobileno);
	}
	public void setSubmit() {
		Next.submit();
	} 
public void validateTo_NextPage(String firstname,
			String lastname, String Address, String City,
			String State, String Gender, String Course, String mobileno) {
		this.setFirstName(firstname);
		this.setLastName(lastname);
		this.setADDress(Address);
		this.setCIty(City);
		this.setSTate(State);
		this.setGEnder(Gender);
		this.setCOurse(Course);
		this.setMobileNo(mobileno);
		this.setSubmit();
		
	}
	
} 